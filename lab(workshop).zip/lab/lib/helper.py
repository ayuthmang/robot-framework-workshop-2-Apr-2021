def say_hello_to(name):
    msg = "hello "+name
    return msg

def calculate_nested_loop(max_i, max_j):
    sum = 0
    for i in range(0, int(max_i)):
        for j in range(0, int(max_j)):
            sum += i*j
    return sum

def return_multiple_values():
    return    100,200,300
