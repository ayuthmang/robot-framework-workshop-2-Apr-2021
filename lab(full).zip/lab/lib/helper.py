
def say_hello_to(name):
    text = "Hello "+name
    return text

# for i=0 to 9
#   for j=0 to 9
#      sum += i*j
def sum_nested_loop(max_i, max_j):
    sum = 0
    for i in range(0, int(max_i)):
        for j in range(0, int(max_j)):
            sum += i*j
    return sum

# print(sum_nested_loop(10,10))
# print(say_hello_to("John"))
